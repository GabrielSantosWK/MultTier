To install the service in windows:

- Compile the project.
- Copy the exe to C:\Windows.
- Open the Command Prompt.
- Go to C:\Windows: "cd Windows"
- Install the service: "Bird.Socket.Service.exe /install".